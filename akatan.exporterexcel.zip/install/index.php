<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Bitrix\Main\Localization\Loc;
use \Bitrix\Main\ModuleManager;
use \Bitrix\Main\EventManager;
use \Bitrix\Main\Application;
use \Bitrix\Main\Loader;
use \Bitrix\Main\IO\Directory;
use \Bitrix\Main\IO\File;
use \Bitrix\Main\Config\Option;
use \Bitrix\Iblock\IblockTable;
use \Bitrix\Iblock\PropertyTable;
use \Bitrix\Main\SiteTable;

Loc::loadMessages(__FILE__);

class Akatan_Exporterexcel extends CModule
{
    public string $IBLOCK_TYPE_ID = 'services';
    public string $IBLOCK_CODE = 'uploading_order';
    public string $IBLOCK_API_CODE = 'uploading0rder';
    public array $exclusionAdminFiles;

    public function __construct()
    {
        include __DIR__ . '/version.php';

        if (isset($arModuleVersion['VERSION'], $arModuleVersion['VERSION_DATE']))
        {
            $this->MODULE_VERSION = $arModuleVersion['VERSION'];
            $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        }

        $this->MODULE_ID = 'akatan.exporterexcel';
        $this->MODULE_NAME = Loc::getMessage('AKATAN_EXCEL_MODULE_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('AKATAN_EXCEL_MODULE_DESCRIPTION');
        $this->PARTNER_NAME = Loc::getMessage('AKATAN_EXCEL_PARTNER_NAME');
        $this->PARTNER_URI = Loc::getMessage('AKATAN_EXCEL_PARTNER_URI');
        $this->MODULE_GROUP_RIGHTS = 'Y';
        $this->exclusionAdminFiles = [
            '.',
            '..',
            'menu.php',
        ];
    }

    /**
     * Установка модуля
     * @return void
     */
    public function DoInstall(): void
    {
        global $USER, $APPLICATION;

//        $MODULE_RIGHT = $APPLICATION->GetGroupRight($this->MODULE_ID);
//        if ($MODULE_RIGHT>="W") {}
        if (!$USER->IsAdmin())
        {
            $APPLICATION->AuthForm(Loc::getMessage('ACCESS_DENIED'));
        }

        if (
            $this->isVersionPHP() &&
            $this->isVersionD7()
        ) {
            $context = Application::getInstance()->getContext();
            $request = $context->getRequest();
            $session = Application::getInstance()->getSession();
            $step = (int)trim(htmlspecialcharsbx(strip_tags($request->getPost('step'))));

            // не существует или меньше 2
            if ($step < 2) {
                $APPLICATION->IncludeAdminFile(
                    Loc::getMessage('AKATAN_EXCEL_INSTALL_TITLE_STEP_1'),
                    __DIR__ . '/step1.php'
                );
            }
            if ($step === 2) {
                $selected_sites = (is_array($request['selected_sites']) && (count($request['selected_sites']) > 0)) ?
                    serialize($request['selected_sites']) : '';
                //exit(print_r($request->getPost('install'),true));
                // регистрируем модуль
                ModuleManager::registerModule($this->MODULE_ID);
                // теперь можно использовать неймспейсы
                if ($request->getPost('install') !== null) {
                    Option::set($this->MODULE_ID, 'SELECTED_SITES', $selected_sites);
                }
                $this->InstallDB();
                $this->InstallEvents();
                $this->InstallFiles();

                $APPLICATION->IncludeAdminFile(
                    Loc::getMessage('AKATAN_EXCEL_INSTALL_TITLE_STEP_2'),
                    __DIR__ . '/step2.php'
                );
            }
        } else {
            $APPLICATION->ThrowException(Loc::getMessage('AKATAN_EXCEL_INSTALL_ERROR_VERSION'));
        }
    }

    /**
     * Удаление модуля
     * @return void
     */
    public function DoUninstall(): void
    {
        global $USER, $APPLICATION;

        if (!$USER->IsAdmin())
        {
            $APPLICATION->AuthForm(Loc::getMessage('ACCESS_DENIED'));
        }
        $request = Application::getInstance()->getContext()->getRequest();
        $step = (int)trim(htmlspecialcharsbx(strip_tags($request->get('step'))));

        if ($step < 2) {
            $APPLICATION->IncludeAdminFile(
                Loc::getMessage('AKATAN_EXCEL_UNINSTALL_TITLE'),
                __DIR__ . '/unstep1.php'
            );
        } elseif ($step === 2) {
            $this->UnInstallDB([
                'savedata' => trim(htmlspecialcharsbx(strip_tags($request->getPost('savedata')))) === 'Y'
            ]);
            $this->UnInstallEvents();
            $this->UnInstallFiles();

            ModuleManager::unRegisterModule($this->MODULE_ID);

            $APPLICATION->IncludeAdminFile(
                Loc::getMessage('AKATAN_EXCEL_UNINSTALL_TITLE'),
                __DIR__ . '/unstep2.php'
            );
        }
    }

    /**
     * Работа с базой данных
     * @return boolean
     */
    public function InstallDB(): bool
    {
        Loader::includeModule('iblock');

        // Получаем выбранные сайты из настроек
        $selectedSites = unserialize(Option::get($this->MODULE_ID, 'SELECTED_SITES', ''));
        $iblockId = null;
        if (!$selectedSites) {
            // Если сайты не выбраны, используем все активные сайты
            $sites = $this->getAllSites();
            $selectedSites = array_keys($sites);
        }

        $this->createUserFields();

        // Создаем тип инфоблока, если не существует
        $iblockType = new \CIBlockType;

        $arFields = [
            'ID' => $this->IBLOCK_TYPE_ID,
            'SECTIONS' => 'Y',
            'IN_RSS' => 'N',
            'SORT' => 100,
            'LANG' => [
                'ru' => [
                    'NAME' => Loc::getMessage('AKATAN_EXCEL_IBLCK_TYPE_NAME_RU'),
                    'SECTION_NAME' => 'Разделы',
                    'ELEMENT_NAME' => 'Элементы'
                ],
                'en' => [
                    'NAME' => Loc::getMessage('AKATAN_EXCEL_IBLCK_TYPE_NAME_EN'),
                    'SECTION_NAME' => 'Sections',
                    'ELEMENT_NAME' => 'Elements'
                ]
            ]
        ];

        if (!$iblockType->GetByID($this->IBLOCK_TYPE_ID)->Fetch()) {
            $iblockType->Add($arFields);
        }

        // Создаем инфоблок
        $iblock = new \CIBlock;
        $arFields = [
            'ACTIVE' => 'Y',
            'NAME' => Loc::getMessage('AKATAN_EXCEL_IBLOCK_NAME'),
            'CODE' => $this->IBLOCK_CODE,
            'API_CODE' => $this->IBLOCK_API_CODE,
            'IBLOCK_TYPE_ID' => $this->IBLOCK_TYPE_ID,
            'SITE_ID' => $selectedSites,
            'SORT' => 100,
            'GROUP_ID' => ['2' => 'R'],
            'VERSION' => 2,
            'LIST_MODE' => 'C',
            'INDEX_ELEMENT' => 'N',
            'INDEX_SECTION' => 'N',
            'WORKFLOW' => 'N',
            'BIZPROC' => 'N',
            'SECTION_CHOOSER' => 'L',
            'LIST_PAGE_URL' => '',
            'SECTION_PAGE_URL' => '',
            'DETAIL_PAGE_URL' => '',
            'DESCRIPTION_TYPE' => 'text',
            'DESCRIPTION' => 'Инфоблок для хранения данных выгрузки',
            'XML_ID' => $this->IBLOCK_CODE,
        ];

        $res_iblock = \CIBlock::GetList(
            [],
            Array(
                'TYPE'=>$this->IBLOCK_TYPE_ID,
                'ACTIVE'=>'Y',
                "CNT_ACTIVE"=>"Y",
                "CODE"=>$this->IBLOCK_CODE
            ), true
        );
        $res_iblock->SelectedRowsCount();
//        while($ar_res = $res->Fetch())
//        {
//            echo $ar_res['NAME'].': '.$ar_res['ELEMENT_CNT'];
//        }

        if ($res_iblock->SelectedRowsCount() === 0) {
            $iblockId = $iblock->Add($arFields);
            $fields = \CIBlock::getFields($iblockId);
            $fields['CODE']['IS_REQUIRED'] = 'Y';
            $fields['CODE']['DEFAULT_VALUE']['UNIQUE'] = 'Y';
            $fields['CODE']['DEFAULT_VALUE']['TRANSLITERATION'] = 'Y';
            \CIBlock::setFields($iblockId, $fields);
            // Создаем пользовательские свойства
            $this->createProperties($iblockId);
        } else {
            while($arIBlock = $res_iblock->Fetch()) {
                $iblockId = $arIBlock['ID'];
                break;
            }
        }
        if ($iblockId) {
            // Сохраняем ID инфоблока в настройках модуля
            Option::set($this->MODULE_ID, 'IBLOCK_ID', $iblockId);
        }

        \CAgent::AddAgent( '\Uploading0rders\Services\AgentUploadSale::runImportFile();', $this->MODULE_ID, 'N', 60 );
        \CAgent::AddAgent( '\Uploading0rders\Services\AgentUploadAnalysis::runImportFile();', $this->MODULE_ID, 'N', 60 );
        \CAgent::AddAgent( '\Uploading0rders\Services\Agent::deleteModuleLoadingFiles();', $this->MODULE_ID, 'N', 86400 );

        return true;
    }

    /**
     *
     * @param $iblockId Id инфоблока
     * @return void
     */
    private function createProperties(int $iblockId): void
    {
        if ($iblockId <= 0) {
            return;
        }

        $properties = null;
        $propertyFields = null;
        $iblockProperty = null;

        $properties = [
            'BY_DATE' => [
                'NAME' => 'Дата',
                'SORT' => 100,
                'PROPERTY_TYPE' => 'S',
                'USER_TYPE' => 'DateTime',
                'IS_REQUIRED' => 'Y'
            ],
            'COUNTERPARTY' => [
                'NAME' => 'Контрагент',
                'SORT' => 200,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'Y'
            ],
            'ARTICLE' => [
                'NAME' => 'Артикул',
                'SORT' => 300,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'N'
            ],
            'NOMENCLATURE' => [
                'NAME' => 'Номенклатура',
                'SORT' => 400,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'N'
            ],
            'CHAR_NOMENCLATURE' => [
                'NAME' => 'Характеристика номенклатуры',
                'SORT' => 500,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'N'
            ],
            'MOTION_DOCUMENT' => [
                'NAME' => 'Документ движения',
                'SORT' => 600,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'N'
            ],
            'QUANTITY' => [
                'NAME' => 'Количество',
                'SORT' => 700,
                'PROPERTY_TYPE' => 'N',
                'IS_REQUIRED' => 'N'
            ],
            'AMOUNT' => [
                'NAME' => 'Сумма',
                'SORT' => 800,
                'PROPERTY_TYPE' => 'N',
                'IS_REQUIRED' => 'Y'
            ],
            'BIND_USER_1C' => [
                'NAME' => 'Пользователь',
                'SORT' => 900,
                'PROPERTY_TYPE' => 'S',
                'IS_REQUIRED' => 'N',
                'USER_TYPE' => 'UserID',
            ]
        ];

        foreach ($properties as $code => $property) {
            $propertyFields = [
                'NAME' => $property['NAME'],
                'ACTIVE' => 'Y',
                'SORT' => $property['SORT'],
                'CODE' => $code,
                'PROPERTY_TYPE' => $property['PROPERTY_TYPE'],
                'IBLOCK_ID' => $iblockId,
                'IS_REQUIRED' => $property['IS_REQUIRED'],
                'MULTIPLE' => 'N'
            ];

            if (isset($property['USER_TYPE'])) {
                $propertyFields['USER_TYPE'] = $property['USER_TYPE'];
            }

            $iblockProperty = new \CIBlockProperty;
            $iblockProperty->Add($propertyFields);
        }

        unset(
            $properties,
            $propertyFields,
            $iblockProperty
        );

    }

    private function createUserFields(): void
    {
        $user_field_name = 'UF_USER_1C';
        $userTypeEntity = new \CUserTypeEntity();
        $ufProperty = null;
        $userFieldId = null;

        // добавить пользовательское свойство для объекта  User
        $ufProperty = \Bitrix\Main\UserFieldTable::getList([
            'select' => ['ID', 'FIELD_NAME'],
            'filter' => ['FIELD_NAME' => $user_field_name],
        ])->fetchAll();


        if (empty($ufProperty)) {
            $userFieldId = $userTypeEntity->Add([
                'FIELD_NAME' => $user_field_name,
                'XML_ID' => $user_field_name,
                'ENTITY_ID' => 'USER',
                'USER_TYPE_ID' => 'string',
                /* Подпись в форме редактирования */
                'EDIT_FORM_LABEL' => [
                    'ru' => 'Связка с 1С',
                    'en' => 'Связка с 1С',
                ],
                /* Заголовок в списке */
                'LIST_COLUMN_LABEL' => [
                    'ru' => 'Связка с 1С',
                    'en' => 'Связка с 1С',
                ],
                /* Подпись фильтра в списке */
                'LIST_FILTER_LABEL' => [
                    'ru' => 'Связка с 1С',
                    'en' => 'Связка с 1С',
                ],
                /* Помощь */
                'HELP_MESSAGE' => [
                    'ru' => 'Связка с 1С',
                    'en' => 'Связка с 1С',
                ]
            ]);
        }

        unset(
            $user_field_name,
            $ufProperty,
            $userFieldId,
            $userTypeEntity
        );
    }

    private function deleteUserFields(): void
    {
        $user_field_name = 'UF_USER_1C';
        $userTypeEntity = new \CUserTypeEntity();
        $ufProperty = null;

        $ufProperty = \Bitrix\Main\UserFieldTable::getList([
            'select' => ['ID', 'FIELD_NAME'],
            'filter' => ['FIELD_NAME' => $user_field_name],
        ])->fetchAll();

        // удалить пользовательское свойство для объекта  User
        if (!empty($ufProperty)) {
            $userTypeEntity->Delete($ufProperty[0]['ID']);
        }

        unset(
            $user_field_name,
            $ufProperty,
            $userTypeEntity
        );
    }

    /**
     * Работа с базой данных
     * @param array $arParams
     * @return boolean
     */
    public function UnInstallDB(array $arParams = []): bool
    {
        Loader::includeModule('iblock');

        $iblockId = Option::get($this->MODULE_ID, 'IBLOCK_ID');
        if (!$arParams['savedata']) {
            if ($iblockId) {
                // Удаляем инфоблок со всеми данными
                \CIBlock::Delete($iblockId);

                // Удаляем тип инфоблока
                \CIBlockType::Delete($this->IBLOCK_TYPE_ID);
            }

            $this->deleteUserFields();
        }

        // Удаляем настройки модуля
        Option::delete($this->MODULE_ID);

        \CAgent::RemoveModuleAgents($this->MODULE_ID);

        return true;
    }

    /**
     * Работа с файлами
     * @param array $arParams
     * @return boolean
     */
    public function InstallFiles(array $arParams = []): bool
    {
        $path_admin = $this->GetPath() . '/install/admin';
        $path_component = $this->GetPath() . '/install/components';
        $path_upload = $_SERVER['DOCUMENT_ROOT'] . '/upload/' . $this->MODULE_ID . '/';

        if (Directory::isDirectoryExists($path_admin)) {
            CopyDirFiles(
                $path_admin,
                $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin'
            ); // Если есть файлы для
            if ($dir = opendir($path_admin)) {
                while (false !== $item = readdir($dir)) {
                    // в $this->exclusionAdminFiles содержаться файлы-исключения
                    if (in_array($item, $this->exclusionAdminFiles)) {
                        continue;
                    }
                    file_put_contents(
                        $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/' . $this->MODULE_ID . '__' . $item,
                                  '<' . '?php require(\'' . realpath($this->GetPath(true) . '/install/admin/' . $item) . '\');?>'
                    );
                }
                closedir($dir);
            }
        } else {
            throw new \Bitrix\Main\IO\InvalidPathException($path_admin);
        }

        if (Directory::isDirectoryExists($path_component)) {
            CopyDirFiles(
                $path_component,
                $_SERVER['DOCUMENT_ROOT'] . '/bitrix/components',
                true,
                true
            );
        } else {
            throw new \Bitrix\Main\IO\InvalidPathException($path_component);
        }

        // Создаем папку для загрузок
        if (!is_dir($path_upload)) {
            mkdir($path_upload, 0755, true);
        }

        return true;
    }

    /**
     * Работа с файлами
     * @return boolean
     */
    public function UnInstallFiles(): bool
    {
        $path_upload = $_SERVER['DOCUMENT_ROOT'] . '/upload/' . $this->MODULE_ID . '/';

        if (Directory::isDirectoryExists($path = $this->GetPath() . '/install/admin')) {
            DeleteDirFiles(
                $_SERVER['DOCUMENT_ROOT'] . $this->GetPath() . '/install/admin/',
                $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin'
            );
            if ($dir = opendir($path)) {
                while (false !== $item = readdir($dir)) {
                    if (in_array($item, $this->exclusionAdminFiles)) {
                        continue;
                    }
                    File::deleteFile($_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/' . $this->MODULE_ID . '__' . $item);
                }
                closedir($dir);
            }
            unset($path);
        }

        if (Directory::isDirectoryExists($path = $this->GetPath() . '/install/components')) {
            Directory::deleteDirectory(
                $_SERVER['DOCUMENT_ROOT'] . '/bitrix/components/akatan/list.element-bind/'
            );
            unset($path);
        }



        // Удаляем папку модуля в upload с загруженными файлами
        if (is_dir($path_upload)) {
            // Удаляем все файлы в папке
            $files = glob($path_upload . '*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
            // Удаляем саму папку
            rmdir($path_upload);
        }

        return true;
    }

    public function InstallEvents(): bool
    {
        // ToDo::агент для удаления старых файлов в /upload катлоге модуля
        return true;
    }

    public function UnInstallEvents(): bool
    {
        // ToDo::агент для удаления старых файлов в /upload катлоге модуля
        return true;
    }

    private function getAllSites()
    {
        $sites = [];

        $dbSites = SiteTable::getList([
            'filter' => ['ACTIVE' => 'Y'],
            'order' => ['SORT' => 'ASC']
        ]);

        while ($site = $dbSites->fetch()) {
            $sites[$site['LID']] = $site['NAME'] . ' [' . $site['LID'] . ']';
        }

        return $sites;
    }

    /**
     * Проверяет поддержку D7 ядра
     * @return mixed
     */
    private function isVersionD7(): mixed
    {
        return CheckVersion(
            ModuleManager::getVersion('main'),
            '14.00.00'
        );
    }

    private function isVersionPHP(): mixed
    {
        return version_compare(PHP_VERSION, '8.0.0') >= 0;
    }

    /**
     * Права доступа
     * @return array[]
     */
    public function GetModuleRightList(): array
    {
        return [
            'reference_id' => ['D', 'K', 'S', 'W'],
            'reference' => [
                '[D] ' . Loc::getMessage('AKATAN_EXCEL_DENIED'),
                '[K] ' . Loc::getMessage('AKATAN_EXCEL_READ_COMPONENT'),
                '[S] ' . Loc::getMessage('AKATAN_EXCEL_WRITE_SETTINGS'),
                '[W] ' . Loc::getMessage('AKATAN_EXCEL_FULL'),
            ]
        ];
    }

    /**
     * Получение пути до текущей дирректории от корня
     */
    public function GetPath($notDocumentRoot = false)
    {
        if ($notDocumentRoot) {
            return str_ireplace(
                Application::getDocumentRoot(), '', dirname(__DIR__)
            );
        } else {
            return dirname(__DIR__);
        }
    }
}